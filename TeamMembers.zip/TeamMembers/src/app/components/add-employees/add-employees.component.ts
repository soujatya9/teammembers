import { Component, OnInit } from '@angular/core';
import { Employees } from 'src/app/models/employees.model';
import { EmployeesService } from 'src/app/services/employees.service';

@Component({
  selector: 'app-add-employees',
  templateUrl: './add-employees.component.html',
  styleUrls: ['./add-employees.component.css']
})
export class AddEmployeesComponent implements OnInit {

  employees: Employees = {
    name: '',
    empid: '',
    online: false
  };
  submitted = false;

  constructor(private employeesService: EmployeesService) { }

  ngOnInit(): void {
  }

  saveEmployees(): void {
    const data = {
      name: this.employees.name,
      empid: this.employees.empid
    };

    this.employeesService.create(data)
      .subscribe({
        next: (res) => {
          console.log(res);
          this.submitted = true;
        },
        error: (e) => console.error(e)
      });
  }

  newEmployees(): void {
    this.submitted = false;
    this.employees = {
      name: '',
      empid: '',
      online: false
    };
  }

}