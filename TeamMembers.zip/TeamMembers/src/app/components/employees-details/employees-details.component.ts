import { Component, Input, OnInit } from '@angular/core';
import { EmployeesService } from 'src/app/services/employees.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Employees } from 'src/app/models/employees.model';

@Component({
  selector: 'app-employees-details',
  templateUrl: './employees-details.component.html',
  styleUrls: ['./employees-details.component.css']
})
export class EmployeesDetailsComponent implements OnInit {

  @Input() viewMode = false;

  @Input() currentEmployees: Employees = {
    name: '',
    empid: '',
    online: false
  };
  
  message = '';

  constructor(
    private employeesService: EmployeesService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    if (!this.viewMode) {
      this.message = '';
      this.getEmployees(this.route.snapshot.params["id"]);
    }
  }

  getEmployees(id: string): void {
    this.employeesService.get(id)
      .subscribe({
        next: (data) => {
          this.currentEmployees = data;
          console.log(data);
        },
        error: (e) => console.error(e)
      });
  }

  updateOnline(status: boolean): void {
    const data = {
      name: this.currentEmployees.name,
      empid: this.currentEmployees.empid,
      online: status
    };

    this.message = '';

    this.employeesService.update(this.currentEmployees.id, data)
      .subscribe({
        next: (res) => {
          console.log(res);
          this.currentEmployees.online = status;
          this.message = res.message ? res.message : 'The status was updated successfully!';
        },
        error: (e) => console.error(e)
      });
  }

  updateEmployees(): void {
    this.message = '';

    this.employeesService.update(this.currentEmployees.id, this.currentEmployees)
      .subscribe({
        next: (res) => {
          console.log(res);
          this.message = res.message ? res.message : 'This employee was updated successfully!';
        },
        error: (e) => console.error(e)
      });
  }

  deleteEmployees(): void {
    this.employeesService.delete(this.currentEmployees.id)
      .subscribe({
        next: (res) => {
          console.log(res);
          this.router.navigate(['/employees']);
        },
        error: (e) => console.error(e)
      });
  }

}