import { Component, OnInit } from '@angular/core';
import { Employees } from 'src/app/models/employees.model';
import { EmployeesService } from 'src/app/services/employees.service';

@Component({
  selector: 'app-employees-list',
  templateUrl: './employees-list.component.html',
  styleUrls: ['./employees-list.component.css']
})
export class EmployeesListComponent implements OnInit {

  employees?: Employees[];
  currentEmployees: Employees = {};
  currentIndex = -1;
  title = '';

  constructor(private employeesService: EmployeesService) { }

  ngOnInit(): void {
    this.retrieveEmployees();
  }

  retrieveEmployees(): void {
    this.employeesService.getAll()
      .subscribe({
        next: (data) => {
          this.employees = data;
          console.log(data);
        },
        error: (e) => console.error(e)
      });
  }

  refreshList(): void {
    this.retrieveEmployees();
    this.currentEmployees = {};
    this.currentIndex = -1;
  }

  setActiveEmployees(employees: Employees, index: number): void {
    this.currentEmployees = employees;
    this.currentIndex = index;
  }

  removeAllEmployees(): void {
    this.employeesService.deleteAll()
      .subscribe({
        next: (res) => {
          console.log(res);
          this.refreshList();
        },
        error: (e) => console.error(e)
      });
  }

  searchName(): void {
    this.currentEmployees = {};
    this.currentIndex = -1;

    this.employeesService.findByName(this.title)
      .subscribe({
        next: (data) => {
          this.employees = data;
          console.log(data);
        },
        error: (e) => console.error(e)
      });
  }

}