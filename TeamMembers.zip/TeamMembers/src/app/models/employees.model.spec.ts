import { Employees } from './employees.model';

describe('Employees', () => {
  it('should create an instance', () => {
    expect(new Employees()).toBeTruthy();
  });
});
