export class Employees {
    id?: any;
    name?: string;
    empid?: string;
    online?: boolean;
  }